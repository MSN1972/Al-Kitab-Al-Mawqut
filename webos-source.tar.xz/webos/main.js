(function () {
'use strict';
const core = window.PrayerCore;
const $ = id => document.getElementById(id);
const dom = {
 display: $('display'), quiet: $('quiet'), settings: $('settings'), clock: $('clock'), gregorian: $('gregorian'), hijri: $('hijri'),
 cards: $('prayer-cards'), prayer: $('next-prayer'), remaining: $('countdown'), status: $('status'), hadith: $('hadith'), grid: $('settings-grid')
};
const KEY = 'alkitab-webos-settings-v1';
const CACHE = 'alkitab-webos-calendar-v1';
const hadiths = [
 'عن ابن عمر رضي الله عنهما: «صلاة الجماعة تفضل صلاة الفذ بسبع وعشرين درجة» — صحيح البخاري (645)',
 'عن أبي هريرة رضي الله عنه: «أقرب ما يكون العبد من ربه وهو ساجد فأكثروا الدعاء» — صحيح مسلم (482)',
 'عن أبي موسى رضي الله عنه: «من صلى البردين دخل الجنة» — صحيح البخاري (574)، صحيح مسلم (635)'
];
function safelyParse(raw, fallback) { try { return JSON.parse(raw) || fallback; } catch (_) { return fallback; } }
const options = safelyParse(localStorage.getItem(KEY), {});
function normalList(values, defaults, min, max) {
 return Array.from({length:5}, (_, i) => {
   const n = Number(Array.isArray(values) ? values[i] : defaults[i]);
   return Number.isFinite(n) ? Math.round(Math.max(min, Math.min(max,n))) : defaults[i];
 });
}
let offsets = normalList(options.offsets, core.DEFAULT_OFFSETS, 0, 120);
let durations = normalList(options.durations, core.DEFAULT_QUIET, 1, 30);
let days = safelyParse(localStorage.getItem(CACHE), {});
let syncBusy = false, lastSyncAttempt = 0, lastClockDate = '', lastMode = '', demoUntil = 0;
let hadithIndex = 0, status = 'مواقيت محفوظة عند توفرها';
const fmtClock = new Intl.DateTimeFormat('en-GB',{timeZone:core.TIMEZONE,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
const fmtGregorian = new Intl.DateTimeFormat('ar-SA-u-ca-gregory',{timeZone:core.TIMEZONE,weekday:'long',day:'numeric',month:'long',year:'numeric'});
let fmtHijri = null;
try {
 const f = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura',{timeZone:core.TIMEZONE,day:'numeric',month:'long',year:'numeric'});
 if (f.resolvedOptions().calendar === 'islamic-umalqura') fmtHijri = f;
} catch(_) {}
function save() { localStorage.setItem(KEY, JSON.stringify({offsets,durations})); }
function renderHadith() {
 dom.hadith.textContent = hadiths[hadithIndex];
 dom.hadith.style.animation = 'none';
 void dom.hadith.offsetWidth;
 dom.hadith.style.animation = 'slide 32s linear infinite';
}
function setStatus(msg) { status = msg; dom.status.textContent=msg; }
function buildCards(today, nextIndex) {
 dom.cards.textContent='';
 for (let i=0;i<5;i++) {
  const cell = document.createElement('article');
  cell.className='prayer-card'+(i===nextIndex ? ' active' : '');
  const n=document.createElement('div'); n.className='prayer-name'; n.textContent=core.ARABIC[i];
  const t=document.createElement('div');t.className='prayer-adhan';t.textContent=today ? core.minToLabel(today[i]) : '--:--';
  const q=document.createElement('div');q.className='prayer-iqama';q.textContent=today ? 'الإقامة '+core.minToLabel(today[i]+offsets[i]) : 'لم تُحمّل المواقيت';
  cell.append(n,t,q);dom.cards.appendChild(cell);
 }
}
function configure() {
 dom.grid.textContent='';
 core.ARABIC.forEach((name, index) => {
  const row=document.createElement('article');row.className='setting-card';
  const title=document.createElement('h2');title.textContent=name;row.appendChild(title);
  control(row,'الإقامة بعد الأذان',offsets,index,0,120);
  control(row,'مدة الصلاة الهادئة',durations,index,1,30);
  dom.grid.appendChild(row);
 });
}
function control(target, label, values, index, min, max) {
 const l=document.createElement('div');l.className='setting-label';l.textContent=label;target.appendChild(l);
 const group=document.createElement('div');group.className='control';
 const dec=document.createElement('button');dec.type='button';dec.textContent='−';dec.setAttribute('aria-label','تقليل '+label+' '+core.ARABIC[index]);
 const value=document.createElement('span');value.className='setting-value';value.textContent=values[index];
 const inc=document.createElement('button');inc.type='button';inc.textContent='+';inc.setAttribute('aria-label','زيادة '+label+' '+core.ARABIC[index]);
 function apply(delta){values[index]=Math.min(max,Math.max(min,values[index]+delta)); value.textContent=values[index];save(); tick();}
 dec.onclick=()=>apply(-1);inc.onclick=()=>apply(1);
 group.append(dec,value,inc);target.appendChild(group);
}
function showSettings() { dom.settings.classList.remove('hidden');configure();$('settings-close').focus(); }
function hideSettings() { dom.settings.classList.add('hidden'); $('settings-open').focus();tick(); }
$('settings-open').onclick=showSettings;
$('settings-close').onclick=hideSettings;
$('save-close').onclick=hideSettings;
$('refresh').onclick=()=>{lastSyncAttempt=0;void synchronize();};
$('preview').onclick=()=>{hideSettings();demoUntil=Date.now()+10000;tick();};
document.addEventListener('keydown', e=>{
 if (e.key==='Escape'||e.key==='Backspace'||e.key==='BrowserBack') {
   if (!dom.settings.classList.contains('hidden')) {e.preventDefault();hideSettings();}
 } else if (e.key==='F1') showSettings();
});
window.addEventListener('webOSRelaunch',()=>{ tick(); });
function normalizedDayObject(data, ym) {
 if (!Array.isArray(data)) return null;
 const output={};
 for (const item of data) {
  const raw=item && item.date && item.date.gregorian && item.date.gregorian.date;
  const m=/^(\d{2})-(\d{2})-(\d{4})$/.exec(raw||'');
  if (!m) return null;
  const ymd=m[3]+'-'+m[2]+'-'+m[1];
  if (!ymd.startsWith(ym+'-')) continue;
  const checked=core.validatedSchedule(item.timings);
  if (!checked) return null;
  output[ymd]=checked;
 }
 const [yr,mo]=ym.split('-').map(Number);
 const numDays=new Date(Date.UTC(yr,mo,0)).getUTCDate();
 return Object.keys(output).length===numDays ? output : null;
}
async function fetchMonth(ym) {
 const [year,month]=ym.split('-');
 const url='https://api.aladhan.com/v1/calendar/'+year+'/'+Number(month)+'?latitude=21.4225&longitude=39.8262&method=4&timezonestring=Asia%2FRiyadh';
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
 try {
  const resp=await fetch(url,{signal:controller.signal,cache:'no-store'});
  if (!resp.ok) throw Error('network');
  const result=await resp.json();
  if (Number(result.code)!==200) throw Error('provider');
  return normalizedDayObject(result.data,ym);
 } finally {clearTimeout(timer);}
}
async function synchronize() {
 if (syncBusy || Date.now()-lastSyncAttempt<30000) return;
 syncBusy=true;lastSyncAttempt=Date.now();
 const date=core.partsForRiyadh(Date.now()).date;
 const needed=Array.from(new Set([core.dayAdd(date,-1),date,core.dayAdd(date,1)].map(x=>x.slice(0,7))));
 const pending=needed.filter(ym=>!days[ym] || Date.now() - (days[ym].fetchedAt||0)>7*86400000);
 let success=true;
 for (const ym of pending) {
  try {
   const fetched=await fetchMonth(ym);
   if (!fetched) {success=false;continue;}
   days[ym]={calendar:fetched,fetchedAt:Date.now()};
   localStorage.setItem(CACHE,JSON.stringify(days));
  } catch (_) {success=false;}
 }
 syncBusy=false;
 if (Object.keys(assembleDays(date)).length===0) setStatus('تعذر تحميل مواقيت الصلاة — اتصل بالإنترنت');
 else setStatus(success ? 'تقويم أم القرى · طريقة الحساب ٤' : 'مواقيت محفوظة محلياً — تعذر التحديث');
 tick();
}
function assembleDays(today) {
 const out={};
 for (const d of [core.dayAdd(today,-1),today,core.dayAdd(today,1)]) {
  const byMonth=days[d.slice(0,7)];
  const times=byMonth && byMonth.calendar && byMonth.calendar[d];
  if (Array.isArray(times) && times.length===5) out[d]=times;
 }
 return out;
}
function tick() {
 const now=Date.now(), p=core.partsForRiyadh(now);
 dom.clock.textContent=fmtClock.format(new Date(now));
 dom.gregorian.textContent=fmtGregorian.format(new Date(now));
 dom.hijri.textContent=fmtHijri ? fmtHijri.format(new Date(now)) : 'تاريخ هجري غير متاح';
 const today=p.date, available=assembleDays(today);
 const events=core.getEvents(available,offsets,durations);
 const state=core.screenAt(now,events);
 const quiet=state.mode==='quiet'||now<demoUntil;
 dom.quiet.classList.toggle('hidden',!quiet);
 dom.display.classList.toggle('hidden',quiet);
 if (quiet) {lastMode='quiet';return;}
 const next=state.next;
 dom.prayer.textContent=next ? 'صلاة '+core.ARABIC[next.index] : 'غير متاح';
 dom.remaining.textContent=core.remainingLabel(state.remainingSec);
 dom.status.textContent=status;
 if(lastClockDate!==today || lastMode!==String(next&&next.index) || !dom.cards.childElementCount){
   buildCards(available[today]||null, next && next.date===today ? next.index:-1);
   lastClockDate=today;
   lastMode=String(next&&next.index);
 }
}
renderHadith();
setInterval(()=>{hadithIndex=(hadithIndex+1)%hadiths.length;renderHadith();},32000);
setInterval(tick,1000);
setInterval(()=>{void synchronize();},6*3600000);
tick();void synchronize();
})();
