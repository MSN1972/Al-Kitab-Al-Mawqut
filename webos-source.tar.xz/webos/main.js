(function () {
'use strict';
const core = window.PrayerCore;
const $ = id => document.getElementById(id);
const dom = {
 display: $('display'), quiet: $('quiet'), adhkar: $('post-prayer'), adhkarPrayer: $('post-prayer-name'), settings: $('settings'), clock: $('clock'), gregorian: $('gregorian'), hijri: $('hijri'),
 cards: $('prayer-cards'), prayer: $('next-prayer'), remaining: $('countdown'), status: $('status'), hadith: $('hadith'), grid: $('settings-grid')
};
const KEY = 'alkitab-webos-settings-v1';
const CACHE = 'alkitab-webos-calendar-v1';
const hadiths = (Array.isArray(window.PrayerHadiths) ? window.PrayerHadiths : [])
 .filter(item => item && /^(صحيح البخاري|صحيح مسلم)$/.test(item.book) &&
         typeof item.text === 'string' && item.text.length > 10 &&
         typeof item.source === 'string' && item.url &&
         /^https:\/\/sunnah\.com\/(bukhari|muslim):[0-9]+[a-z]?$/.test(item.url));
function safelyParse(raw, fallback) { try { return JSON.parse(raw) || fallback; } catch (_) { return fallback; } }
const options = safelyParse(localStorage.getItem(KEY), {});
function normalList(values, defaults, min, max) {
 return Array.from({length:5}, (_, i) => {
   const n = Number(Array.isArray(values) ? values[i] : defaults[i]);
   return Number.isFinite(n) ? Math.round(Math.max(min, Math.min(max,n))) : defaults[i];
 });
}
let offsets = normalList(options.offsets, core.DEFAULT_OFFSETS, 0, 120);
let durations = normalList(options.durations, core.DEFAULT_QUIET, 1, 30);
let corrections = normalList(options.corrections, [0,0,0,0,0], -20, 20);
let tickerSeconds = Math.max(35, Math.min(120, Number(options.tickerSeconds) || 60));
let adhkarMinutes = Number.isFinite(Number(options.adhkarMinutes))
 ? Math.max(0, Math.min(15, Math.round(Number(options.adhkarMinutes)))) : 4;
let days = safelyParse(localStorage.getItem(CACHE), {});
let syncBusy = false, lastSyncAttempt = 0, lastClockDate = '', lastMode = '', demoUntil = 0, demoAdhkarUntil = 0;
let hadithIndex = 0, status = 'مواقيت محفوظة عند توفرها';
const fmtClock = new Intl.DateTimeFormat('en-GB',{timeZone:core.TIMEZONE,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
const fmtGregorian = new Intl.DateTimeFormat('ar-SA-u-ca-gregory',{timeZone:core.TIMEZONE,weekday:'long',day:'numeric',month:'long',year:'numeric'});
let fmtHijri = null;
try {
 const f = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura',{timeZone:core.TIMEZONE,day:'numeric',month:'long',year:'numeric'});
 if (f.resolvedOptions().calendar === 'islamic-umalqura') fmtHijri = f;
} catch(_) {}
function save() { localStorage.setItem(KEY, JSON.stringify({offsets,durations,corrections,tickerSeconds,adhkarMinutes})); }
function renderHadith() {
 if(!hadiths.length) {dom.hadith.textContent='';return;}
 const entry=hadiths[hadithIndex];
 dom.hadith.textContent = (entry.excerpt ? 'مقتطف من حديث صحيح: ' : 'قال رسول الله ﷺ: ') +
   '«' + entry.text + '» — ' + entry.source;
 dom.hadith.style.animation = 'none';
 void dom.hadith.offsetWidth;
 dom.hadith.style.animation = 'slide ' + tickerSeconds + 's linear 1';
}
function setStatus(msg) { status = msg; dom.status.textContent=msg; }
function buildCards(today, nextIndex) {
 dom.cards.textContent='';
 for (let i=0;i<5;i++) {
  const cell = document.createElement('article');
  cell.className='prayer-card'+(i===nextIndex ? ' active' : '');
  const n=document.createElement('div'); n.className='prayer-name'; n.textContent=core.ARABIC[i];
  const t=document.createElement('div');t.className='prayer-adhan';t.textContent=today ? core.minToLabel(today[i]) : '--:--';
  const q=document.createElement('div');q.className='prayer-iqama';q.textContent=today ? 'الإقامة '+core.minToLabel(today[i]+offsets[i]) : 'لم تُحمّل المواقيت';
  cell.append(n,t,q);dom.cards.appendChild(cell);
 }
}
function configure() {
 dom.grid.textContent='';
 core.ARABIC.forEach((name, index) => {
  const row=document.createElement('article');row.className='setting-card';
  const title=document.createElement('h2');title.textContent=name;row.appendChild(title);
  control(row,'تصحيح وقت الأذان بالدقائق',corrections,index,-20,20);
  control(row,'الإقامة بعد الأذان',offsets,index,0,120);
  control(row,'مدة الصلاة الهادئة',durations,index,1,30);
  dom.grid.appendChild(row);
 });
 const tickerRow=document.createElement('article');tickerRow.className='setting-card ticker-setting';
 const title=document.createElement('h2');title.textContent='شريط الأحاديث';tickerRow.appendChild(title);
 const desc=document.createElement('div');desc.className='setting-label';desc.textContent='مدة تمرير الحديث (ثانية)';tickerRow.appendChild(desc);
 const counter=document.createElement('div');counter.className='control';
 const minus=document.createElement('button');minus.textContent='−';minus.type='button';
 const number=document.createElement('span');number.className='setting-value';number.textContent=tickerSeconds;
 const plus=document.createElement('button');plus.textContent='+';plus.type='button';
 function setSpeed(delta){tickerSeconds=Math.min(120,Math.max(35,tickerSeconds+delta));number.textContent=tickerSeconds;save();renderHadith();}
 minus.onclick=()=>setSpeed(-5);plus.onclick=()=>setSpeed(5);
 counter.append(minus,number,plus);tickerRow.appendChild(counter);
 const count=document.createElement('div');count.className='setting-label';count.textContent=hadiths.length+' أحاديث موثقة محفوظة محلياً';tickerRow.appendChild(count);
 dom.grid.appendChild(tickerRow);
 const adhkarRow=document.createElement('article');adhkarRow.className='setting-card ticker-setting';
 const heading=document.createElement('h2');heading.textContent='أذكار ما بعد الصلاة';adhkarRow.appendChild(heading);
 const desc2=document.createElement('div');desc2.className='setting-label';desc2.textContent='مدة عرض الأذكار بعد انتهاء الصلاة بالدقائق (0 لإيقافها)';adhkarRow.appendChild(desc2);
 const counter2=document.createElement('div');counter2.className='control';
 const minus2=document.createElement('button');minus2.textContent='−';minus2.type='button';
 const count2=document.createElement('span');count2.className='setting-value';count2.textContent=adhkarMinutes;
 const plus2=document.createElement('button');plus2.textContent='+';plus2.type='button';
 function changeAdhkar(delta){adhkarMinutes=Math.max(0,Math.min(15,adhkarMinutes+delta));count2.textContent=adhkarMinutes;save();tick();}
 minus2.onclick=()=>changeAdhkar(-1);plus2.onclick=()=>changeAdhkar(1);
 counter2.append(minus2,count2,plus2);adhkarRow.appendChild(counter2);
 dom.grid.appendChild(adhkarRow);
}
function control(target, label, values, index, min, max) {
 const l=document.createElement('div');l.className='setting-label';l.textContent=label;target.appendChild(l);
 const group=document.createElement('div');group.className='control';
 const dec=document.createElement('button');dec.type='button';dec.textContent='−';dec.setAttribute('aria-label','تقليل '+label+' '+core.ARABIC[index]);
 const value=document.createElement('span');value.className='setting-value';value.textContent=values[index];
 const inc=document.createElement('button');inc.type='button';inc.textContent='+';inc.setAttribute('aria-label','زيادة '+label+' '+core.ARABIC[index]);
 function apply(delta){values[index]=Math.min(max,Math.max(min,values[index]+delta)); value.textContent=values[index];save(); lastClockDate="";tick();}
 dec.onclick=()=>apply(-1);inc.onclick=()=>apply(1);
 group.append(dec,value,inc);target.appendChild(group);
}
function showSettings() { dom.settings.classList.remove('hidden');configure();$('settings-close').focus(); }
function hideSettings() { dom.settings.classList.add('hidden'); $('settings-open').focus();tick(); }
$('settings-open').onclick=showSettings;
$('settings-close').onclick=hideSettings;
$('save-close').onclick=hideSettings;
$('refresh').onclick=()=>{lastSyncAttempt=0;void synchronize();};
$('preview').onclick=()=>{hideSettings();demoAdhkarUntil=0;demoUntil=Date.now()+10000;tick();};
$('preview-adhkar').onclick=()=>{hideSettings();demoUntil=0;demoAdhkarUntil=Date.now()+10000;tick();};
document.addEventListener('keydown', e=>{
 if (e.key==='Escape'||e.key==='Backspace'||e.key==='BrowserBack') {
   if (!dom.settings.classList.contains('hidden')) {e.preventDefault();hideSettings();}
 } else if (e.key==='F1') showSettings();
});
window.addEventListener('webOSRelaunch',()=>{ tick(); });
function normalizedDayObject(data, ym) {
 if (!Array.isArray(data)) return null;
 const output={};
 for (const item of data) {
  const raw=item && item.date && item.date.gregorian && item.date.gregorian.date;
  const m=/^(\d{2})-(\d{2})-(\d{4})$/.exec(raw||'');
  if (!m) return null;
  const ymd=m[3]+'-'+m[2]+'-'+m[1];
  if (!ymd.startsWith(ym+'-')) continue;
  const checked=core.validatedSchedule(item.timings);
  if (!checked) return null;
  output[ymd]=checked;
 }
 const [yr,mo]=ym.split('-').map(Number);
 const numDays=new Date(Date.UTC(yr,mo,0)).getUTCDate();
 return Object.keys(output).length===numDays ? output : null;
}
async function fetchMonth(ym) {
 const [year,month]=ym.split('-');
 const url='https://api.aladhan.com/v1/calendar/'+year+'/'+Number(month)+'?latitude=21.4225&longitude=39.8262&method=4&timezonestring=Asia%2FRiyadh';
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
 try {
  const resp=await fetch(url,{signal:controller.signal,cache:'no-store'});
  if (!resp.ok) throw Error('network');
  const result=await resp.json();
  if (Number(result.code)!==200) throw Error('provider');
  return normalizedDayObject(result.data,ym);
 } finally {clearTimeout(timer);}
}
async function synchronize() {
 if (syncBusy || Date.now()-lastSyncAttempt<30000) return;
 syncBusy=true;lastSyncAttempt=Date.now();
 const date=core.partsForRiyadh(Date.now()).date;
 const needed=Array.from(new Set([core.dayAdd(date,-1),date,core.dayAdd(date,1)].map(x=>x.slice(0,7))));
 const pending=needed.filter(ym=>!days[ym] || Date.now() - (days[ym].fetchedAt||0)>7*86400000);
 let success=true;
 for (const ym of pending) {
  try {
   const fetched=await fetchMonth(ym);
   if (!fetched) {success=false;continue;}
   days[ym]={calendar:fetched,fetchedAt:Date.now()};
   localStorage.setItem(CACHE,JSON.stringify(days));
  } catch (_) {success=false;}
 }
 syncBusy=false;
 if (Object.keys(assembleDays(date)).length===0) setStatus('تعذر تحميل مواقيت الصلاة — اتصل بالإنترنت');
 else setStatus(success ? 'تقويم أم القرى · طريقة الحساب ٤' : 'مواقيت محفوظة محلياً — تعذر التحديث');
 tick();
}
function adjustedSchedule(raw) {
 if (!Array.isArray(raw) || raw.length!==5) return null;
 const value=raw.map((minute,index) => minute + corrections[index]);
 return value.every((n,i) => Number.isInteger(n) && n>=0 && n<1440 && (i===0 || n>value[i-1])) ? value : raw;
}
function assembleDays(today) {
 const out={};
 for (const d of [core.dayAdd(today,-1),today,core.dayAdd(today,1)]) {
  const byMonth=days[d.slice(0,7)];
  const times=byMonth && byMonth.calendar && byMonth.calendar[d];
  if (Array.isArray(times) && times.length===5) out[d]=adjustedSchedule(times);
 }
 return out;
}
function tick() {
 const now=Date.now(), p=core.partsForRiyadh(now);
 dom.clock.textContent=fmtClock.format(new Date(now));
 dom.gregorian.textContent=fmtGregorian.format(new Date(now));
 dom.hijri.textContent=fmtHijri ? fmtHijri.format(new Date(now)) : 'تاريخ هجري غير متاح';
 const today=p.date, available=assembleDays(today);
 const events=core.getEvents(available,offsets,durations);
 const state=core.screenAt(now,events,adhkarMinutes);
 const quiet=state.mode==='quiet'||now<demoUntil;
 // A quiet prayer always takes precedence over the post-prayer screen and previews.
 const postPrayer=!quiet && (state.mode==='adhkar'||now<demoAdhkarUntil);
 dom.quiet.classList.toggle('hidden',!quiet);
 dom.adhkar.classList.toggle('hidden',!postPrayer);
 dom.display.classList.toggle('hidden',quiet||postPrayer);
 if (quiet) {lastMode='quiet';return;}
 if (postPrayer) {
   dom.adhkarPrayer.textContent=state.mode==='adhkar' ? 'بعد صلاة '+core.ARABIC[state.event.index] : 'نموذج أذكار ما بعد الصلاة';
   lastMode='adhkar';return;
 }
 const next=state.next;
 dom.prayer.textContent=next ? 'صلاة '+core.ARABIC[next.index] : 'غير متاح';
 dom.remaining.textContent=core.remainingLabel(state.remainingSec);
 dom.status.textContent=status;
 if(lastClockDate!==today || lastMode!==String(next&&next.index) || !dom.cards.childElementCount){
   buildCards(available[today]||null, next && next.date===today ? next.index:-1);
   lastClockDate=today;
   lastMode=String(next&&next.index);
 }
}
renderHadith();
function advanceHadith() {
 if (hadiths.length) {hadithIndex=(hadithIndex+1)%hadiths.length;renderHadith();}
 setTimeout(advanceHadith,tickerSeconds*1000);
}
setTimeout(advanceHadith,tickerSeconds*1000);
setInterval(tick,1000);
setInterval(()=>{void synchronize();},6*3600000);
tick();void synchronize();
})();
