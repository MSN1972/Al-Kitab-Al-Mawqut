const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs=require('node:fs'), path=require('node:path');
const root=path.join(__dirname,'..');
const read=(x)=>fs.readFileSync(path.join(root,x),'utf8');
const hadiths=JSON.parse(read('hadiths.json'));
const html=read('index.html'),js=read('main.js'),css=read('style.css');
test('hadith library only includes entries from Sahihayn with verifiable links',()=>{
  assert.ok(hadiths.length>=20,'At least 20 individually curated reports');
  assert.equal(new Set(hadiths.map(x=>x.id)).size,hadiths.length,'Unique reports');
  for(const item of hadiths){
    assert.match(item.book,/^(صحيح البخاري|صحيح مسلم)$/);
    assert.match(item.text,/^[\u0600-\u06FF\u0750-\u077F\s،]+$/u);
    assert.ok(item.text.length>15 && item.text.length<175,'Concise readable excerpt');
    assert.match(item.reference,/^\d+[a-z]?$/);
    const prefix=item.book==='صحيح البخاري'?'bukhari':'muslim';
    assert.equal(item.url,`https://sunnah.com/${prefix}:${item.reference}`);
    assert.equal(item.source,`${item.book} (${item.reference})`);
    assert.equal(typeof item.excerpt,'boolean');
  }
});
test('all hadiths bundled offline, Quranic verse is not wrongly attributed to Prophet',()=>{
  const embedded=read('hadiths.js');
  assert.match(embedded,/window.PrayerHadiths=/);
  assert.equal(JSON.parse(embedded.split('window.PrayerHadiths=')[1].trim().replace(/;$/,'')).length,hadiths.length);
  assert.ok(html.indexOf('src="hadiths.js"')<html.indexOf('src="main.js"'));
  assert.doesNotMatch(hadiths.map(x=>x.text).join(' '),/إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ/);
  assert.match(html,/النساء: ١٠٣/);
  assert.match(js,/مقتطف من حديث صحيح/);
});
test('Makkah settings remain persistent and can be adjusted with TV remote',()=>{
  assert.match(js,/options\.corrections/);
  assert.match(js,/offsets,durations,corrections,tickerSeconds/);
  assert.match(js,/Math\.min\(120,Math\.max\(35,tickerSeconds\+delta\)\)/);
  assert.match(js,/adjustedSchedule\(times\)/);
  assert.match(js,/Number\.isInteger\(n\)/);
  assert.match(html,/تصحيح الأذان/);
});
test('gold clock, same gold date style and calm full-screen prayer mode',()=>{
  assert.match(css,/color:#ffdc91/);
  assert.match(css,/color:#f9d98f/);
  assert.match(css,/\.quiet-screen\{position:fixed;inset:0;background:#101922/);
  assert.match(html,/<div id="hijri" class="date-text"/);
  assert.match(html,/<div id="gregorian" class="date-text"/);
});
test('LG TV manifest declares ACG, retains upgrade identity and free offline web app',()=>{
  const manifest=JSON.parse(read('appinfo.json'));
  assert.equal(manifest.id,'com.alkitabmawqut.tv');
  assert.equal(manifest.version,'0.6.0');
  assert.deepEqual(manifest.requiredACG,[]);
  assert.equal(manifest.type,'web');
  for (const x of [manifest.icon,manifest.largeIcon]) assert.ok(fs.existsSync(path.join(root,x)));
});
