const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const core=require('../prayer-core.js');
const base=path.join(__dirname,'..');
const date='2026-10-25';
const times=[300,720,930,1080,1170];
const events=core.getEvents({[date]:times},[15,15,5,5,15],[7,7,5,5,7]);
const at=(min,sec=0)=>core.epochInRiyadh(date,min)+sec*1000;
const read=x=>fs.readFileSync(path.join(base,x),'utf8');

test('no remembrance appears before or during prayer',()=>{
 assert.equal(core.screenAt(at(314),events,4).mode,'display');
 assert.equal(core.screenAt(at(315),events,4).mode,'quiet');
 assert.equal(core.screenAt(at(321,59),events,4).mode,'quiet');
});
test('remembrance appears exactly when prayer quiet-mode ends',()=>{
 const state=core.screenAt(at(322),events,4);
 assert.equal(state.mode,'adhkar');
 assert.equal(state.event.index,0);
 assert.equal(state.until,at(326));
});
test('remembrance expires precisely after configured time',()=>{
 assert.equal(core.screenAt(at(325,59),events,4).mode,'adhkar');
 assert.equal(core.screenAt(at(326),events,4).mode,'display');
});
test('zero duration disables remembrance completely',()=>{
 assert.equal(core.screenAt(at(322),events,0).mode,'display');
});
test('other prayer and next day after-midnight events',()=>{
 assert.equal(core.screenAt(at(742),events,4).mode,'adhkar');
 const nextDay=core.dayAdd(date,1);
 const late=core.getEvents({[date]:[300,720,930,1080,1438]},[15,15,5,5,6],[7,7,5,5,7]);
 const midnight=core.epochInRiyadh(nextDay,0);
 assert.equal(core.screenAt(midnight+5*60000,late,4).mode,'quiet');
 assert.equal(core.screenAt(midnight+11*60000,late,4).mode,'adhkar');
 assert.equal(core.screenAt(midnight+15*60000,late,4).mode,'display');
});
test('out-of-range remembrance duration is clamped',()=>{
 assert.equal(core.screenAt(at(326),events,100).mode,'adhkar');
 assert.equal(core.screenAt(at(337),events,100).mode,'display');
});
test('three authenticated, explicitly sourced remembrance records',()=>{
 const entries=JSON.parse(read('post-prayer-adhkar.json'));
 assert.equal(entries.length,3);
 assert.deepEqual(entries.map(x=>x.source),['صحيح مسلم (591)','صحيح البخاري (844)','صحيح مسلم (597)']);
 assert.ok(entries.every(x=>/^https:\/\/sunnah\.com\//.test(x.url)));
 assert.deepEqual(entries[2].items.map(x=>x.count),['٣٣ مرة','٣٣ مرة','٣٣ مرة']);
});
test('screen exists separately from no-text quiet screen and uses no animation',()=>{
 const html=read('index.html');
 assert.match(html,/id="quiet" class="quiet-screen hidden"/);
 assert.match(html,/id="post-prayer" class="post-prayer-screen hidden"/);
 assert.match(html,/صحيح مسلم \(591\)/);
 assert.match(html,/صحيح البخاري \(844\)/);
 assert.match(html,/صحيح مسلم \(597\)/);
 const css=read('style.css');
 assert.match(css,/\.post-prayer-screen\{/);
 const section=css.slice(css.indexOf('/* Post-prayer remembrance'));
 assert.doesNotMatch(section,/animation\s*:/);
});
test('remote UI has selectable duration and preview; screen priority is quiet',()=>{
 const html=read('index.html');const js=read('main.js');
 assert.match(html,/id="preview-adhkar"/);
 assert.match(js,/adhkarMinutes:?[ ,}]/);
 assert.match(js,/const quiet=state.mode==='quiet'\|\|now<demoUntil/);
 assert.match(js,/const postPrayer=!quiet/);
});
