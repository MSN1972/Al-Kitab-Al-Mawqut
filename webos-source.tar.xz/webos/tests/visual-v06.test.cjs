const { test }=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=n=>fs.readFileSync(path.join(root,n),'utf8');
const html=read('index.html'), css=read('style.css');
test('live clock and both calendars share the same panel',()=>{
 const panel=html.match(/<div class="clock-panel"[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/)?.[0];
 assert.ok(panel);for(const id of ['clock','gregorian','hijri'])assert.ok(panel.includes(`id="${id}"`));
 assert.doesNotMatch(html,/class="hijri-panel"/);
});
test('remembrance page is not one flattened image and is entirely unnumbered',()=>{
 assert.match(html,/<main id="post-prayer"/);
 for(const heading of ['الاستغفار بعد السلام','ذكر السلام','التهليل والدعاء','التسبيح والتحميد والتكبير'])assert.match(html,new RegExp(heading));
 const content=html.slice(html.indexOf('id="post-prayer"'),html.indexOf('id="settings"'));
 assert.doesNotMatch(content,/class="(?:item-number|number-badge|adhkar-number)"/);
 assert.ok((content.match(/<section class="post-prayer-card/g)||[]).length===4);
 assert.match(css,/\.post-prayer-content\{display:grid;direction:rtl;grid-template-columns:repeat\(3/);
});
test('enhanced CC0 image is referenced as a distinct photo, not a static full UI',()=>{
 assert.match(css,/kaaba-4k-cinematic\.jpg/);
 assert.match(html,/src="assets\/brand-icon.png"/);
 assert.match(html,/id="countdown"/);
 assert.match(html,/id="hadith"/);
});
test('quiet prayer remains flat and lacks moving assets',()=>{
 assert.match(css,/\.quiet-screen\{position:fixed;inset:0;background:#101922/);
 assert.doesNotMatch(html,/<main id="quiet"[^>]*>\s*<img/);
});
