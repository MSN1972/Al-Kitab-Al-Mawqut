/* Framework-free, pure scheduling logic, shared with Node tests. Times are HH:mm in Asia/Riyadh. */
(function (root) {
  'use strict';
  const PRAYERS = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
  const ARABIC = ['الفجر','الظهر','العصر','المغرب','العشاء'];
  const DEFAULT_OFFSETS = [15, 15, 5, 5, 15];
  const DEFAULT_QUIET = [7, 7, 5, 5, 7];
  const TIMEZONE = 'Asia/Riyadh';
  function pad(n) { return String(n).padStart(2, '0'); }
  function minute(time) {
    if (typeof time !== 'string') return null;
    const m = /^(\d{1,2}):(\d{2})/.exec(time);
    if (!m) return null;
    const h = +m[1], mm = +m[2];
    return h >= 0 && h <= 23 && mm >= 0 && mm < 60 ? h * 60 + mm : null;
  }
  function dayAdd(ymd, amount) {
    const value = new Date(ymd + 'T12:00:00Z');
    if (isNaN(value)) return null;
    value.setUTCDate(value.getUTCDate() + amount);
    return value.toISOString().slice(0,10);
  }
  function epochInRiyadh(ymd, minutes) {
    // Arabia Standard Time has UTC+03:00 and no DST. Only dates in Saudi Arabia are supported.
    return Date.parse(ymd + 'T00:00:00+03:00') + minutes * 60000;
  }
  function partsForRiyadh(epochMillis) {
    const date = new Date(epochMillis + 3 * 3600000);
    return {date: date.toISOString().slice(0,10), hhmm: pad(date.getUTCHours())+':'+pad(date.getUTCMinutes()), seconds: date.getUTCSeconds()};
  }
  function validatedSchedule(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const out = [];
    for (const n of PRAYERS) {
      let value = minute(raw[n]);
      if (value === null) return null;
      out.push(value);
    }
    if (out.some((m,i) => i > 0 && m <= out[i-1])) return null;
    return out;
  }
  function getEvents(daySchedules, offsets, durations) {
    const events = [];
    for (const date of Object.keys(daySchedules || {}).sort()) {
      const raw = daySchedules[date];
      const mins = Array.isArray(raw) && raw.length === 5 && raw.every(v => Number.isInteger(v) && v >= 0 && v < 1440) ? raw : null;
      if (!mins) continue;
      for (let i = 0; i < 5; i++) {
        const delay = Math.max(0, Math.min(120, Number(offsets[i]) || 0));
        const duration = Math.max(1, Math.min(30, Number(durations[i]) || 1));
        const start = epochInRiyadh(date, mins[i] + delay);
        events.push({date, index:i, adhan:mins[i], iqama:minToLabel(mins[i]+delay), start, end:start+duration*60000});
      }
    }
    return events.sort((a,b) => a.start-b.start);
  }
  function minToLabel(min) { return pad(Math.floor(((min % 1440)+1440)%1440 / 60)) + ':' + pad(((min % 60)+60)%60); }
  function screenAt(now, events) {
    const e = events.find(item => now >= item.start && now < item.end);
    if (e) return {mode:'quiet', event:e};
    const future = events.find(item => item.start > now);
    return {mode: 'display', next: future || null, remainingSec: future ? Math.max(0,Math.ceil((future.start-now)/1000)) : null};
  }
  function remainingLabel(sec) {
    if (sec === null || !isFinite(sec)) return '--:--';
    sec=Math.max(0, Math.floor(sec));
    return sec>=3600 ? pad(Math.floor(sec/3600))+':'+pad(Math.floor(sec%3600/60))+':'+pad(sec%60) : pad(Math.floor(sec/60))+':'+pad(sec%60);
  }
  const api = {PRAYERS, ARABIC, DEFAULT_OFFSETS, DEFAULT_QUIET, TIMEZONE, minute, dayAdd, epochInRiyadh, partsForRiyadh, validatedSchedule, getEvents, screenAt, minToLabel, remainingLabel};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.PrayerCore=api;
})(typeof window !== 'undefined' ? window : globalThis);
